package com.androidnative;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.androidnative.features.CameraAPI;
import com.androidnative.features.social.twitter.ANTwitter;
import com.unity3d.player.UnityPlayer;

public class AndroidNativeProxy extends Activity {
	private static final String BRIDGED_INTENT_KEY = "BRIDGED_INTENT";
	private static final String BRIDGED_REQUEST_CODE_KEY = "BRIDGED_REQUEST_CODE_KEY";
	private static final String TASK_ID = "TASK_ID";
	
	
	private static final int START_ACTIVITY_FOR_RESULT_TASK = 0;
	private static final int CHOOSE_IMAGE_TASK = 1;  

	

	@Override
    protected void onStart() {
		
		
		int taskID = getIntent().getIntExtra(TASK_ID, -1);
		switch(taskID) {
			case START_ACTIVITY_FOR_RESULT_TASK: 
				StartActivity();
				break;
			case CHOOSE_IMAGE_TASK:
				GetImageFromGallery();
				break;
		}
    
		

        super.onStart();
    }
	
	
	private void StartActivity() {
		int requestCode = getIntent().getIntExtra(BRIDGED_REQUEST_CODE_KEY, 0);
		Intent bridgedIntent = (Intent) getIntent().getParcelableExtra(BRIDGED_INTENT_KEY);
        
		startActivityForResult(bridgedIntent, requestCode);
	}
	
	 @Override
	 protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		Log.d("AndroidNative", "AndroidNativeProxy::onActivityResult");
		try {
			 CameraAPI.GetInstance().onActivityResult(requestCode, resultCode, data);
		} catch (Exception ex) {
			ex.printStackTrace();
			Log.d("AndroidNative", "GooglePlaySupportActivity::onActivityResult Error: " + ex.getMessage());
		}
		
		
	 	super.onActivityResult(requestCode, resultCode, data);

	 	
	 	finish(); 
	 }
	 
	 
	@Override
	public void onNewIntent(Intent intent) {

		Log.d("AndroidNative", "AndroidNativeProxy::onNewIntent");
		try {
			ANTwitter.GetInstance().SetIntent(intent);
		} catch (Throwable ex) {
			Log.d("AndroidNative", "onNewIntent has failed");
		}
		
		super.onNewIntent(intent);
		finish();
		
	}

	
	
	public static void startProxyForResult(Intent intent, int requestCode) {
		Intent i = new Intent(UnityPlayer.currentActivity, AndroidNativeProxy.class);
		
		i.putExtra(TASK_ID, START_ACTIVITY_FOR_RESULT_TASK);
		i.putExtra(BRIDGED_REQUEST_CODE_KEY, requestCode);
		i.putExtra(BRIDGED_INTENT_KEY, intent);
		

		UnityPlayer.currentActivity.startActivity(i);
	}
	
	
	public static void startImageChooserProxy() {
		Intent i = new Intent(UnityPlayer.currentActivity, AndroidNativeProxy.class);
		i.putExtra(TASK_ID, CHOOSE_IMAGE_TASK);
		
		UnityPlayer.currentActivity.startActivity(i);
	}
	
	
	
	// --------------------------------------
	// Camera And Gallery
	// --------------------------------------
	
	public void GetImageFromGallery() {
		CameraAPI.GetInstance().StartImageChooser(this);
	}
	

}
