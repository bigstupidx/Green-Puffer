package com.androidnative.billing.core;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.androidnative.billing.core.listeners.AN_PurchaseFinishedListener;
import com.androidnative.billing.interfaces.OnBillingSetupFinishedListener;
import com.androidnative.billing.interfaces.OnConsumeFinishedListener;
import com.androidnative.billing.interfaces.QueryInventoryFinishedListener;
import com.androidnative.billing.models.BillingResult;
import com.androidnative.billing.models.Inventory;
import com.androidnative.billing.models.Purchase;
import com.androidnative.billing.models.SkuDetails;
import com.unity3d.player.UnityPlayer;


public class BillingManager {
	
	
	public static final int PURCHASE_REQUEST = 999;

	public static final String UNITY_LISTNER_NAME = "AndroidInAppPurchaseManager";
	public static final String UNITY_SPLITTER = "|";
	public static final String TAG = "AndroidNative";
	
	public static boolean sendRequest = false;

	private Inventory inventory = null;

	public BillingHelper mHelper;
	public ArrayList<String> productList = null;
	
	private static BillingManager _instance = null;


	public static BillingManager GetInstance() {
		if(_instance == null) {
			_instance =  new BillingManager();
		}
		
		return _instance;
	}
	
	public Inventory GetInventory() {
		return inventory;
	}
	
	
	
	
	//Proxy Calls	
	public static void AN_Connect(String ids, String base64EncodedPublicKey) {
		ArrayList<String> products = new ArrayList<String>();
		String[] result = ids.split(",");

		for (String id : result) {
			products.add(id);
		}

		GetInstance().connect(products, base64EncodedPublicKey);
	}
	
	public static void AN_RetrieveProducDetails() {
		GetInstance().retrieveProducDetails();
	}
	
	public static void AN_Purchase(String SKU, String developerPayload) {
		GetInstance().purchase(SKU, developerPayload);
	}
	
	public static void AN_Subscribe(String SKU, String developerPayload) {
		GetInstance().subscribe(SKU, developerPayload);
	}
	
	public static void AN_Consume(String SKU) {
		GetInstance().consume(SKU);
	}
	
	
	
	
	
	
	//API's
	public void connect(ArrayList<String> products, String base64EncodedPublicKey) {
		try {
			productList = products;

			mHelper = new BillingHelper(UnityPlayer.currentActivity, base64EncodedPublicKey);
			mHelper.enableDebugLogging(true);

			mHelper.startSetup(new OnBillingSetupFinishedListener() {
				public void onSetupFinished(BillingResult result) {
					
					StringBuilder callback =  new StringBuilder();
					callback.append(Integer.toString(result.getResponse()));
					callback.append(UNITY_SPLITTER);
					callback.append(result.getMessage());
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnBillingSetupFinishedCallback", callback.toString());

				}
			});   

		} catch(Exception ex) {
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnBillingSetupFinishedCallback", callback.toString());
			
			Log.d(BillingManager.TAG, ex.getMessage());
		}

	}

	
	private ArrayList<String> delayedItems;
	
	

	public void retrieveProducDetails() {
		delayedItems = new  ArrayList<String>();
		startRetrieveRequest(productList);
	}
	
	public void startRetrieveRequest(ArrayList<String> products) {
		try {
			QueryInventoryFinishedListener  mQueryFinishedListener =  new QueryInventoryFinishedListener() {

				@Override
				public void onQueryInventoryFinished(BillingResult result, Inventory inv) {
					
					Log.d(BillingManager.TAG, "onQueryInventoryFinished: ");
					if (result.isSuccess()) {

						inventory = inv;
						
						 StringBuilder ownedInfo = new StringBuilder();
						 List<Purchase> purchases  = inventory.getAllPurchases();
						 
						 boolean first = true;
						 for(Purchase p : purchases) {
							 if(!first) {
								 ownedInfo.append(UNITY_SPLITTER);
							 }
							 ownedInfo.append(p.getSku());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getPackageName());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getDeveloperPayload());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getOrderId());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getPurchaseState());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getToken());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getSignature());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getPurchaseTime());
							 ownedInfo.append(UNITY_SPLITTER);
							 ownedInfo.append(p.getOriginalJson());
							 
							 first = false;
						 }
						 
						 UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPurchasesRecive", ownedInfo.toString());
						
						 first = true;
						 StringBuilder productsInfo = new StringBuilder();
						 List<SkuDetails> products  = inventory.getAllProducts();
						 for(SkuDetails p : products) {
							 if(!first) {
								 productsInfo.append(UNITY_SPLITTER);
							 }
							 
							
							  Log.d(BillingManager.TAG, "SkuDetails: " + p.getSku());
								
							 
		
							 productsInfo.append(p.getSku());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getPrice());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getTitle());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getDescription());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getPriceAmountMicros());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getmPriceCurrencyCode());
							 productsInfo.append(UNITY_SPLITTER);
							 productsInfo.append(p.getOriginalJson());
							
							 
							 first = false;
						 }
						 
						 UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnProducttDetailsRecive", productsInfo.toString());
					

					}
					
					
					if(delayedItems.size() > 0) {
						startRetrieveRequest(new ArrayList<String>(delayedItems));
					} else {
						StringBuilder callback =  new StringBuilder();
						callback.append(Integer.toString(result.getResponse()));
						callback.append(UNITY_SPLITTER);
						callback.append(result.getMessage());
						
						UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnQueryInventoryFinishedCallBack", callback.toString());
					}
					
					

				}
			};

			
			
			
			int count = 0;
			ArrayList<String> query = new ArrayList<String>();
			delayedItems =  new ArrayList<String>();
			
			if(products.size() > 0) {
				for(int i = 0; i < products.size(); i++) {
					count++;
					if(count >= 9) {
						delayedItems.add(products.get(i));
					} else {
						query.add(products.get(i));
					}
				}
				
				
				
				if(query.size() > 0) {
					mHelper.queryInventoryAsync(true, query, mQueryFinishedListener);  
				}	
				
			} else {
				Log.d(BillingManager.TAG, "No prodcuts to retrive");
			}
			
	
		} catch(Exception ex) {
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnQueryInventoryFinishedCallBack", callback.toString());
			
			Log.d("AndroidNative", ex.getMessage());
		}
		
	}
	
	
	public void consume(String SKU) {
		
		Log.d(BillingManager.TAG, "Billing consume " + SKU);
		
		try {
			OnConsumeFinishedListener mConsumeFinishListner = new OnConsumeFinishedListener() {
				
				@Override
				public void onConsumeFinished(Purchase purchase, BillingResult result) {
					StringBuilder callback =  new StringBuilder();
					callback.append(Integer.toString(result.getResponse()));
					callback.append(UNITY_SPLITTER);
					callback.append(result.getMessage());
					
					Log.d("AndroidNative", "**Consume finished: " + result.getMessage());

					if (result.isSuccess()) {

						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getSku());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getPackageName());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getDeveloperPayload());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getOrderId());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getPurchaseState());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getToken());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getSignature());
						callback.append(UNITY_SPLITTER);
						callback.append(purchase.getOriginalJson());
						
						if(inventory != null) {
							inventory.erasePurchase(purchase.getSku());
						} 
						
				    }
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnConsumeFinishedCallBack", callback.toString());
					
				}
			};
			
			mHelper.consumeAsync(inventory.getPurchase(SKU), mConsumeFinishListner);
		} catch(Exception ex) {
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnConsumeFinishedCallBack", callback.toString());
			
			Log.d(BillingManager.TAG, ex.getMessage());
		}
		
	}
	
	public void purchase(String SKU, String developerPayload) {
		
		Log.d(BillingManager.TAG, "Billing purchase " + SKU);
		
		sendRequest = true;
		
		Intent i = new Intent(UnityPlayer.currentActivity, AN_BillingProxyActivity.class);
        i.putExtra("sku", SKU);
        i.putExtra("inapp", true);
        i.putExtra("developerPayload", developerPayload);

        // Launch proxy purchase Activity - it will close itself down when we have a response
        UnityPlayer.currentActivity.startActivity(i);

	}
	
	
	public void launchPurchaseFlow(Activity act, String sku, String developerPayload) {
		try {
			mHelper.launchPurchaseFlow(act, sku, PURCHASE_REQUEST,  new AN_PurchaseFinishedListener(), developerPayload);
		} catch(Exception ex) {
			
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPurchaseFinishedCallback", callback.toString());
			UnityPlayer.currentActivity.sendBroadcast(new Intent(AN_BillingProxyActivity.ACTION_FINISH));
			
			Log.d("BillingManager", ex.getMessage());
		}
		
	}
	
	  public void subscribe(String SKU, String developerPayload) {
			Log.d(BillingManager.TAG, "Billing subscribe " + SKU);
			
			sendRequest = true;
			
			Intent i = new Intent(UnityPlayer.currentActivity, AN_BillingProxyActivity.class);
	        i.putExtra("sku", SKU);
	        i.putExtra("inapp", false);
	        i.putExtra("developerPayload", developerPayload);

	        // Launch proxy purchase Activity - it will close itself down when we have a response
	        UnityPlayer.currentActivity.startActivity(i);
			
		}
	  
	  
	
	public void launchSubscribeFlow(Activity act, String sku, String developerPayload) {
		try {
			mHelper.launchSubscriptionPurchaseFlow(act, sku, PURCHASE_REQUEST, new AN_PurchaseFinishedListener(), developerPayload);
		} catch(Exception ex) {
			
			StringBuilder callback =  new StringBuilder();
			callback.append(Integer.toString(BillingHelper.IABHELPER_UNKNOWN_ERROR));
			callback.append(UNITY_SPLITTER);
			callback.append(ex.getMessage());
			UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPurchaseFinishedCallback", callback.toString());
			UnityPlayer.currentActivity.sendBroadcast(new Intent(AN_BillingProxyActivity.ACTION_FINISH));
			
			Log.d("BillingManager", ex.getMessage());
		}
	}
	
	
  
	
	
	public void handleActivityResult(int requestCode, int resultCode, Intent data)  {
		if(mHelper != null) {
			mHelper.handleActivityResult(requestCode, resultCode, data);
		}
	}



	public void dispose() {
		if(mHelper != null) {
			mHelper.dispose();
		}
		
		_instance = null;
		mHelper = null;
	}
	
	
}
