package com.androidnative.billing.interfaces;

import com.androidnative.billing.models.BillingResult;
import com.androidnative.billing.models.Inventory;

/**
 * Listener that notifies when an inventory query operation completes.
 */
public interface QueryInventoryFinishedListener {
    /**
     * Called to notify that an inventory query operation completed.
     *
     * @param result The result of the operation.
     * @param inv The inventory.
     */
    public void onQueryInventoryFinished(BillingResult result, Inventory inv);
}
