/** Automatically generated file. DO NOT MODIFY */
package com.example.an_billing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}