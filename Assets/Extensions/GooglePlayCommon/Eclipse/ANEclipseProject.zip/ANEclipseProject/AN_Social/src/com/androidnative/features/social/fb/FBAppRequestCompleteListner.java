package com.androidnative.features.social.fb;

import android.os.Bundle;
import android.util.Log;

import com.facebook.FacebookException;
import com.facebook.widget.WebDialog.OnCompleteListener;
import com.unity3d.player.UnityPlayer;

public class FBAppRequestCompleteListner implements OnCompleteListener {

	@Override
	public void onComplete(Bundle values, FacebookException error) {
		
		 final String UNITY_SPLITTER = "|";
		 Log.d("AndroidNative", "Request  completed");
		 
		 
		 if (error != null) {
			 
			 Log.d("AndroidNative", "Error: " + error.toString());
			 UnityPlayer.UnitySendMessage("SPFacebook", "OnAppRequestFailed_AndroidCB", error.toString());
			
         } else {
        	 
        	
        	 
        	 
        	 Log.d("AndroidNative", "values: " + values.toString());
        	 String requestId = values.getString("request");
        	
        	 

        	 
        	 if (requestId == null) {
        		 requestId = "";
        	 }
        	 
        	
        	 
        	 String Recipients = "";
        	 boolean HasNext = true;
        	 int index = 0;
        	 StringBuilder nameBuilder = new StringBuilder();
        	 while(HasNext) {
        		 
        		 String id = values.getString("to[" + index + "]");
        		 if(id == null) {
        			 HasNext = false;
        			 break;
        		 } else {
        			 index++;
        			 nameBuilder.append(id).append(",");
        		 } 
        	 }
        	 
        	 if(index > 0) {
        		 nameBuilder.deleteCharAt(nameBuilder.length() - 1);
        		 Recipients = nameBuilder.toString();
        	 }
        	 

        	 StringBuilder  result = new StringBuilder();
             
     		result.append(requestId);
     		result.append(UNITY_SPLITTER);
     		result.append(Recipients);
     		
   
             UnityPlayer.UnitySendMessage("SPFacebook", "OnAppRequestCompleted_AndroidCB", result.toString());
             
         }
		
	}

}
