
package com.androidnative.gms.core;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;


import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.games.Games;
import com.google.android.gms.plus.Plus;

/**
 * An abstract activity that handles authorization and connection to the Drive
 * services.
 */
public class NewGameHelper {

    /**
     * DriveId of an existing folder to be used as a parent folder in
     * folder operations samples.
     */
    public static final String EXISTING_FOLDER_ID = "0B2EEtIjPUdX6MERsWlYxN3J6RU0";

    /**
     * DriveId of an existing file to be used in file operation samples..
     */
    public static final String EXISTING_FILE_ID = "0ByfSjdPVs9MZTHBmMVdSeWxaNTg";

    /**
     * Extra for account name.
     */
    protected static final String EXTRA_ACCOUNT_NAME = "account_name";

    /**
     * Request code for auto Google Play Services error resolution.
     */
    protected static final int REQUEST_CODE_RESOLUTION = 9001;


    /**
     * Google API client.
     */
    private GoogleApiClient mGoogleApiClient;
    private GameClientManager listner;
    private String _scopes;
    
    
    
    
    /**
     * Construct a GameHelper object, initially tied to the given Activity.
     * After constructing this object, call @link{setup} from the onCreate()
     * method of your Activity.
     */
 
    

    /**
     * Called when activity gets visible. A connection to Drive services need to
     * be initiated as soon as the activity is visible. Registers
     * {@code ConnectionCallbacks} and {@code OnConnectionFailedListener} on the
     * activities itself.
     */
    
    public NewGameHelper(GameClientManager manager, String scopes) {
    	 listner = manager;
    	 _scopes = scopes;
    }
    
    
    
    
    public void sighIn() {
    	sighIn(null);
    }
    
    public void sighIn(String accountName) {
    	Log.d("AndroidNative", "GP::sighIn accountName:" + accountName);
    	GooglePlaySupportActivity.startProxyForGPConnection(accountName);
       
    }
    
    
    public void StartSignRequest(String accountName, Activity act) {
    	 Log.d("AndroidNative", "GP::StartSignRequest accountName:" + accountName);
    	
    	 if (mGoogleApiClient == null) {
         	
         	GoogleApiClient.Builder builder = new GoogleApiClient.Builder(act);
         	Log.d("AndroidNative", "Scopes3:" + _scopes);
         	if(_scopes.contains("GamesAPI")) {
         		Log.d("AndroidNative", "Games.API scope added");
         		builder.addApi(Games.API);
         	}
         	
         	if(_scopes.contains("AppStateAPI")) {
         		Log.d("AndroidNative", "AppStateManager.API scope added");
         		builder.addApi(AppStateManager.API);
         	}
         	
         	if(_scopes.contains("PlusAPI")) {
         		Log.d("AndroidNative", "Plus.API scope added");
         		builder.addApi(Plus.API);
         	}
         	
         	if(_scopes.contains("DriveAPI")) {
         		Log.d("AndroidNative", "Drive.API scope added, SCOPE_APPFOLDER");
         		builder.addApi(Drive.API).addScope(Drive.SCOPE_APPFOLDER);
         	}
         	
         	
         	if(accountName != null) {
         		builder.setAccountName(accountName);
         	}
         	
         	
         	
         	builder.addConnectionCallbacks(listner);
            builder.addOnConnectionFailedListener(listner);
         	
             mGoogleApiClient = builder.build();
            
            
         }
         
         
         mGoogleApiClient.connect();
         Log.d("AndroidNative", "Google Play sighIn started");
    }
    
    public void  reconnect() {
    	mGoogleApiClient.reconnect();
    }
    
    
    public void connect() {
   	 if (mGoogleApiClient != null) {
   		 mGoogleApiClient.connect();
   	 }
   }
    
    public boolean IsConnected() {
    	if (mGoogleApiClient != null) {
      		return mGoogleApiClient.isConnected();
      	}
    	
    	return false;
    }
    
    public void disconnect() {
    	 if (mGoogleApiClient != null) {
    		 mGoogleApiClient.disconnect();
    	 }
    }
    
    
    public ConnectionResult connectionToResolve;
    public void resolveConnection(ConnectionResult con) {
    	if(con.hasResolution()) {
    		connectionToResolve = con;
			GooglePlaySupportActivity.startProxyForGPReolution(REQUEST_CODE_RESOLUTION);
		}
    }
    
    

    /**
     * Handles resolution callbacks.
     */

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    	
        if (requestCode == REQUEST_CODE_RESOLUTION) {
        	Log.d("AndroidNative", "result: REQUEST_CODE_RESOLUTION");
        	if(resultCode == Activity.RESULT_OK) {
        		 mGoogleApiClient.connect();
        	} else {
        		listner.onSignInFailed();
        	}
  
        } 
    }

    /**
     * Called when activity gets invisible. Connection to Drive service needs to
     * be disconnected as soon as an activity is invisible.
     */
    
    public void onPause() {
        if (mGoogleApiClient != null) {
            mGoogleApiClient.disconnect();
        }
    }


    /**
     * Getter for the {@code GoogleApiClient}.
     */
    public GoogleApiClient getGoogleApiClient() {
      return mGoogleApiClient;
    }
}
