package com.androidnative.gms.listeners.savedgames;


import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.snapshot.SnapshotMetadata;
import com.google.android.gms.games.snapshot.Snapshots.CommitSnapshotResult;
import com.unity3d.player.UnityPlayer;

public class SnapshotMetadataChangeListner implements ResultCallback<CommitSnapshotResult>{

	@Override
	public void onResult(CommitSnapshotResult result) {
		

		
		SnapshotMetadata  meta = result.getSnapshotMetadata();
		 
		if(meta != null) {
			Games.Snapshots.open(GameClientManager.GetInstance().API(), meta).setResultCallback(new OpenSnapshotListner("OnSavedGameSaveResult"));
		} else {
			int status = result.getStatus().getStatusCode();
			StringBuilder  builder = new StringBuilder();
			builder.append(status);
			UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnSavedGameSaveResult", builder.toString());
		}
		
		
	}
	

}
