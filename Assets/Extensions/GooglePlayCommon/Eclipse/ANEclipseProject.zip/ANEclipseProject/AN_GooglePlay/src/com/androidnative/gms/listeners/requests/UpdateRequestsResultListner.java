package com.androidnative.gms.listeners.requests;

import java.io.UnsupportedEncodingException;

import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.games.request.Requests;
import com.google.android.gms.games.request.Requests.UpdateRequestsResult;
import com.unity3d.player.UnityPlayer;

public class UpdateRequestsResultListner implements ResultCallback<UpdateRequestsResult>{

	@Override
	public void onResult(UpdateRequestsResult result) {
		// TODO Auto-generated method stub
		 // Scan each result outcome and process accordingly.
		
		StringBuilder builder = new StringBuilder();
		
        for (String requestId : result.getRequestIds()) {
            // We must have a local cached copy of the request
            // and the request needs to be a
            // success in order to continue.
            if (!GameClientManager.gameRequestMap.containsKey(requestId) || result.getRequestOutcome(requestId) != Requests.REQUEST_UPDATE_OUTCOME_SUCCESS) {
                continue;
            }
            
            Log.d("AndroidNative", "accepted " + requestId);
            
            GameRequest r = GameClientManager.gameRequestMap.get(requestId);
           
            builder.append( r.getRequestId());
            builder.append(GameClientManager.UNITY_SPLITTER);
        	String decoded = "";
			try {
				decoded = new String( r.getData(), "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			builder.append(decoded);
			builder.append(GameClientManager.UNITY_SPLITTER);
			builder.append(r.getExpirationTimestamp() );
			builder.append(GameClientManager.UNITY_SPLITTER);
        	builder.append(r.getCreationTimestamp() );
        	builder.append(GameClientManager.UNITY_SPLITTER);
        	builder.append(r.getSender().getPlayerId() );
        	builder.append(GameClientManager.UNITY_SPLITTER);
        	builder.append(r.getType());
        	builder.append(GameClientManager.UNITY_SPLITTER);
            	
           
       
        }
       
        
        builder.append(GameClientManager.UNITY_EOF);
    	UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnGameRequestsAccepted", builder.toString());
    	 Log.d("AndroidNative", "OnGameRequestsAccepted sent");
	}

}
