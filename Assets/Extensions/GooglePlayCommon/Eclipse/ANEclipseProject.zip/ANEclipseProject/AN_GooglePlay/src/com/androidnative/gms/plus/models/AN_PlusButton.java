package com.androidnative.gms.plus.models;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.androidnative.gms.utils.AnUtility;
import com.google.android.gms.plus.PlusOneButton;
import com.google.android.gms.plus.PlusOneButton.OnPlusOneClickListener;
import com.unity3d.player.UnityPlayer;




@SuppressLint("NewApi") 
public class AN_PlusButton {
	
	private LinearLayout layout;
	private String _url;
	private PlusOneButton p;
	private int _size;
	private int _annotation;
	
	
	private int _gravity;
	private int _x;
	private int _y;
	private int _id;
	
	
	private boolean IsShowed = true;
	
	private boolean IsGravityDependent = false;
	
	
	private static final int PLUS_ONE_REQUEST_CODE = 0;
	public static final String CONTROLLER_LISTNER_NAME = "AN_PlusButtonsManager";
	
	
	
	public AN_PlusButton(int id, String url, int size, int annotation) {
		_id = id;
		_size = size;
		_url = url;
		_annotation = annotation;
	
		InitNewButton();
		Show();
	}
	
	
	public void InitNewButton () {
		p =  new PlusOneButton(AnUtility.GetApplicationContex());
		p.setSize(_size);
		p.setAnnotation(_annotation);
		p.initialize(_url, new OnPlusOneClickListener() {
			
			@Override
			public void onPlusOneClick(Intent intent) {
				 Log.d("AndroidNative", "onPlusOneClick");
				 UnityPlayer.UnitySendMessage(CONTROLLER_LISTNER_NAME, "OnPlusClicked", Integer.toString(_id));
				 AnUtility.GetLauncherActivity().startActivityForResult(intent, PLUS_ONE_REQUEST_CODE);
			}
		});
		
		layout = new LinearLayout(AnUtility.GetApplicationContex());
		layout.addView(p, new RelativeLayout.LayoutParams(-2, -2));
	}
	
	
	public void setGravity(int gravity) {
		_gravity = gravity;
		IsGravityDependent = true;
		layout.setGravity(gravity);
	}
	
	public void SetPosition(int x, int y) {
		
		_x = x;
		_y = y;
		IsGravityDependent = false;
		layout.setGravity(Gravity.TOP);
		layout.setX(x);
		layout.setY(y);
	}
	
	
	public void Refresh() {
		RemoveLayout();
		InitNewButton();
		
		if(IsGravityDependent) {
			Log.d("AndroidNative", "AN_PlusButton: setGravity after Refeshr");
			setGravity(_gravity);
		} else {
			Log.d("AndroidNative", "AN_PlusButton: SetPosition Refeshr");
			SetPosition(_x, _y);
		}
		
		Log.d("AndroidNative", "AN_PlusButton: Restoring visual state IsShowed = " + IsShowed);
		if(IsShowed) {
			Show();
		} else {
			Hide();
		}
	}
	
	
	public void Hide() {
		if(layout.getParent() != null) {
		
			IsShowed = false;
			RemoveLayout();
		}
	}
	
	private  void RemoveLayout() {
		ViewGroup vg = (ViewGroup)(layout.getParent());
		vg.removeView(layout);
	}
	
	public void Show() {
		if(layout.getParent() == null) {
			IsShowed = true;
			AnUtility.GetLauncherActivity().addContentView(layout, new RelativeLayout.LayoutParams(-1, -1));
		}
	}
}
