package com.androidnative.gms.core;

import com.androidnative.gms.listeners.savedgames.LoadSnapshotsResultListner;
import com.androidnative.gms.listeners.savedgames.OpenSnapshotListner;
import com.androidnative.gms.network.RealTimeMultiplayerController;
import com.androidnative.gms.utils.AnUtility;
import com.google.android.gms.games.Games;

import android.util.Log;

public class GameClientBridge {
	
	// --------------------------------------
	// Google Play Services
	// --------------------------------------

	public static void playServiceInit(String scopes) {
		try {
			GameClientManager.GetInstance().InitPlayService(scopes);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceInit: "
					+ ex.getMessage());
		}

	}

	public static void playServiceConnect() {
		try {
			GameClientManager.GetInstance().sighIn();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceConnect: "
					+ ex.getMessage());
		}

	}

	public static void playServiceConnect(String accountName) {
		try {
			GameClientManager.GetInstance().sighIn(accountName);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceConnect: "
					+ ex.getMessage());
		}

	}

	public static void getToken() {
		try {
			GameClientManager.GetInstance().getToken();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError getToken: " + ex.getMessage());
		}

	}

	public static void getToken(String accountName, String scope) {
		try {
			GameClientManager.GetInstance().getToken(accountName, scope);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError getToken: " + ex.getMessage());
		}

	}

	public static void invalidateToken(String token) {
		try {
			GameClientManager.GetInstance().invalidateToken(token);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError invalidateToken: "
					+ ex.getMessage());
		}

	}

	public static void loadGoogleAccountNames() {
		try {
			GameClientManager.GetInstance().loadGoogleAccountNames();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadGoogleAccountNames: "
							+ ex.getMessage());
		}

	}

	public static void clearDefaultAccount() {
		try {
			GameClientManager.GetInstance().clearDefaultAccount();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError clearDefaultAccount: "
					+ ex.getMessage());
		}

	}

	public static void revokeAccessAndDisconnect() {
		try {
			GameClientManager.GetInstance().revokeAccessAndDisconnect();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError revokeAccessAndDisconnect: "
							+ ex.getMessage());
		}

	}

	public static void playServiceDisconnect() {
		try {
			GameClientManager.GetInstance().disconnect();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError playServiceDisconnect: "
							+ ex.getMessage());
		}

	}

	public static void showAchievementsUI() {
		try {
			GameClientManager.GetInstance().showAchivmentsUI();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError showAchivments: " + ex.getMessage());
		}

	}

	public static void showLeaderBoards() {
		try {
			GameClientManager.GetInstance().showLeaderBoardsUI();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showLeaderBoards: "
					+ ex.getMessage());
		}

	}

	public static void showLeaderBoard(String leaderboardName) {
		try {
			String leaderboardId = getStringResourceByName(leaderboardName);
			showLeaderBoardById(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError showLeaderBoard" + ex.getMessage());
		}

	}

	public static void showLeaderBoardById(String leaderboardId) {
		try {
			GameClientManager.GetInstance().showLeaderBoardUI(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showLeaderBoardById: "
					+ ex.getMessage());
		}

	}

	public static void loadConnectedPlayers() {
		try {
			GameClientManager.GetInstance().loadConnectedPlayers();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadConnectedPlayers: "
							+ ex.getMessage());
		}

	}

	public static void submitScore(String leaderboardName, String score) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		submitScoreById(leaderboardId, score);
	}

	public static void submitScoreById(String leaderboardId, String score) {
		try {
			GameClientManager.GetInstance().submitScore(leaderboardId,
					Long.parseLong(score));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError submitScoreById: "
					+ ex.getMessage());
		}

	}

	public static void loadLeaderBoards() {
		try {
			GameClientManager.GetInstance().loadLeaderBoards();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadLeaderBoards: "
					+ ex.getMessage());
		}

	}

	public static void updatePlayerScore(String leaderboardId, String span,
			String leaderboardCollection) {
		try {
			GameClientManager.GetInstance().UpdatePlayerScore(leaderboardId,
					Integer.parseInt(span),
					Integer.parseInt(leaderboardCollection));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError updatePlayerScore: "
					+ ex.getMessage());
		}

	}

	public static void loadPlayerCenteredScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		try {
			GameClientManager.GetInstance().loadPlayerCenteredScores(
					leaderboardId, Integer.parseInt(span),
					Integer.parseInt(leaderboardCollection),
					Integer.parseInt(maxResults));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadPlayerCenteredScores: "
							+ ex.getMessage());
		}

	}

	public static void loadTopScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		try {
			GameClientManager.GetInstance().loadTopScores(leaderboardId,
					Integer.parseInt(span),
					Integer.parseInt(leaderboardCollection),
					Integer.parseInt(maxResults));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadTopScores: " + ex.getMessage());
		}

	}

	public static void reportAchievement(String achievementName) {

		String achievementId = getStringResourceByName(achievementName);
		reportAchievementById(achievementId);
	}

	public static void reportAchievementById(String achievementId) {
		try {
			GameClientManager.GetInstance().reportAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError reportAchievementById: "
							+ ex.getMessage());
		}

	}

	public static void revealAchievement(String achievementName) {
		Log.d("AndroidNative", "achievementName: " + achievementName);
		String achievementId = getStringResourceByName(achievementName);

		Log.d("AndroidNative", "achievementId: " + achievementId);
		revealAchievementById(achievementId);
	}

	public static void revealAchievementById(String achievementId) {
		try {
			GameClientManager.GetInstance().revealAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError 	GameClientManager.GetInstance().revealAchievement(achievementId);: "
							+ ex.getMessage());
		}

	}

	public static void incrementAchievement(String achievementName, String numsteps) {
		String achievementId = getStringResourceByName(achievementName);
		incrementAchievementById(achievementId, numsteps);
	}

	public static void incrementAchievementById(String achievementId, String numsteps) {
		try {
			GameClientManager.GetInstance().incrementAchievement(achievementId,
					Integer.parseInt(numsteps));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError incrementAchievementById: "
							+ ex.getMessage());
		}

	}

	public static void loadAchievements() {
		try {
			GameClientManager.GetInstance().loadAchievements();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadAchievements: "
					+ ex.getMessage());
		}

	}

	public static void resetAchievement(String achievementId) {
		try {
			GameClientManager.GetInstance().resetAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError resetAchievement: "
					+ ex.getMessage());
		}

	}

	public static void resetAllAchievements() {
		try {
			GameClientManager.GetInstance().resetAllAchievements();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError resetAllAchievements: "
							+ ex.getMessage());
		}

	}

	public static void resetLeaderBoard(String leaderboardId) {
		try {
			GameClientManager.GetInstance().resetLeaderBoard(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError GameClientManager.GetInstance().resetLeaderBoard(leaderboardId);: "
							+ ex.getMessage());
		}

	}

	// --------------------------------------
	// Gifts
	// --------------------------------------

	public static void sendGiftRequest(String type, String playload,
			String requestLifetimeDays, String icon, String description) {
		try {
			GameClientManager.GetInstance().sendGiftRequest(type, playload,
					requestLifetimeDays, icon, description);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sendGiftRequest: "
					+ ex.getMessage());
		}

	}

	public static void showRequestAccepDialog() {
		try {
			GameClientManager.GetInstance().showRequestAccepDialog();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError GameClientManager.GetInstance().showRequestAccepDialog();: "
							+ ex.getMessage());
		}

	}

	public static void acceptRequests(String ids) {
		try {
			GameClientManager.GetInstance().acceptRequests(ids);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError acceptRequests: " + ex.getMessage());
		}

	}

	public static void dismissRequest(String ids) {
		try {
			GameClientManager.GetInstance().dismissRequest(ids);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError dismissRequest: " + ex.getMessage());
		}

	}

	public static void loadPlayerInfo(String playerId) {
		try {
			GameClientManager.GetInstance().loadPlayerInfo(playerId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadPlayerInfo: " + ex.getMessage());
		}

	}

	// --------------------------------------
	// QUESTS AND EVENTS
	// --------------------------------------

	public static void sumbitEvent(String eventId, String count) {
		try {
			GameClientManager.GetInstance().sumbitEvent(eventId,
					Integer.valueOf(count));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError sumbitEvent: " + ex.getMessage());
		}

	}

	public static void loadEvents() {
		try {
			GameClientManager.GetInstance().loadEvents();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadEvents: " + ex.getMessage());
		}

	}

	public static void showSelectedQuests(String questSelectors) {
		try {
			GameClientManager.GetInstance().showSelectedQuests(questSelectors);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showSelectedQuests: "
					+ ex.getMessage());
		}

	}

	public static void acceptQuest(String questId) {
		try {
			GameClientManager.GetInstance().acceptQuest(questId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError acceptQuest: " + ex.getMessage());
		}

	}

	public static void loadQuests(String questSelectors, String sortOrder) {
		try {
			GameClientManager.GetInstance().loadQuests(questSelectors,
					Integer.valueOf(sortOrder));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError loadQuests: " + ex.getMessage());
		}

	}

	// --------------------------------------
	// RTM
	// --------------------------------------

	public static void RTMFindMatch(String minPlayers, String maxPlayers,
			String bitMask) {
		try {
			RealTimeMultiplayerController.GetInstance().findMatch(
					Integer.valueOf(minPlayers), Integer.valueOf(maxPlayers),
					Integer.valueOf(bitMask));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError RTMFindMatch: " + ex.getMessage());
		}

	}

	public static void sendDataToAll(String data, String sendType) {
		try {
			RealTimeMultiplayerController.GetInstance().sendDataToAll(data,
					Integer.valueOf(sendType));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError sendDataToAll: " + ex.getMessage());
		}

	}

	public static void sendDataToPlayers(String data, String players, String sendType) {
		try {
			RealTimeMultiplayerController.GetInstance().sendDataToPlayers(data,
					players, Integer.valueOf(sendType));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sendDataToPlayers: "
					+ ex.getMessage());
		}

	}

	public static void showWaitingRoomIntent() {
		try {
			RealTimeMultiplayerController.GetInstance().showWaitingRoomIntent();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError showWaitingRoomIntent: "
							+ ex.getMessage());
		}

	}

	public static void leaveRoom() {
		try {
			RealTimeMultiplayerController.GetInstance().leaveRoom();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError leaveRoom: " + ex.getMessage());
		}

	}

	public static void acceptInviteToRoom(String invId) {
		try {
			RealTimeMultiplayerController.GetInstance().acceptInviteToRoom(
					invId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError acceptInviteToRoom: "
					+ ex.getMessage());
		}

	}

	public static void showInvitationBox() {
		try {
			RealTimeMultiplayerController.GetInstance().showInvitationBox();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showInvitationBox: "
					+ ex.getMessage());
		}

	}

	public static void invitePlayers(String minPlayers, String maxPlayers) {
		try {
			RealTimeMultiplayerController.GetInstance().invitePlayers(
					Integer.valueOf(minPlayers), Integer.valueOf(maxPlayers));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative",
					"NoClassDefFoundError invitePlayers: " + ex.getMessage());
		}

	}
	
	
	public static void OnApplicationPause(boolean isPaused) {
		if(isPaused) {
		//GameClientManager.GetInstance().onStop();
		} else {
		//GameClientManager.GetInstance().onStart();
		}
	}
	
	
	// --------------------------------------
	// Saved Games Bridge
	// --------------------------------------
	
	
	
	public static void CreateNewSpanshot_Bridge(String name, String description, String ImageData, String Data, long PlayedTime) {
		GameClientManager.GetInstance().createNewSpanshot(name, description, ImageData, Data, PlayedTime);
	}
	
	public static void ShowSavedGamesUI_Bridge(String title, int maxNumberOfSavedGamesToShow) {
		GameClientManager.GetInstance().showSavedGamesUI(title, maxNumberOfSavedGamesToShow);
	}
	
	public static void ResolveSnapshotsConflict_Bridge(int index) {
		GameClientManager.GetInstance().resolveSnapshotsConflict(index);
	}
	
	public static void OpenSpanshotByName_Bridge(String name) {
		Games.Snapshots.open(GameClientManager.GetInstance().API(), name, true).setResultCallback(new OpenSnapshotListner("OnSavedGamePicked"));
	}
	
	public static void LoadSpanshots_Bridge() {
		Games.Snapshots.load(GameClientManager.GetInstance().API(), true).setResultCallback(new LoadSnapshotsResultListner());
	}
	
	// --------------------------------------
	// Google Cloud  Bridge
	// --------------------------------------
	
	
	public void ListStates_Bridge() {
		GameClientManager.GetInstance().listStates();
	}

	public void UpdateState_Bridge(String stateKey, String data) {
		GameClientManager.GetInstance().updateState(Integer.parseInt(stateKey), data);
	}

	public void DeleteState_Bridge(String stateKey) {
		GameClientManager.GetInstance().deleteState(Integer.parseInt(stateKey));
	}

	public void LoadState_Bridge(String stateKey) {
		GameClientManager.GetInstance().loadState(Integer.parseInt(stateKey));
	}

	public void ResolveState_Bridge(String stateKey, String resolvedData,String resolvedVersion) {
		GameClientManager.GetInstance().resolveState(Integer.parseInt(stateKey),
					resolvedData, resolvedVersion);
		
	}
		

	// --------------------------------------
	// Private Methods
	// --------------------------------------

	private static String getStringResourceByName(String aString) {
		String packageName = AnUtility.GetLauncherActivity().getPackageName();
		int resId = AnUtility.GetLauncherActivity().getResources()
				.getIdentifier(aString, "string", packageName);
		return AnUtility.GetLauncherActivity().getString(resId);
	}
}
