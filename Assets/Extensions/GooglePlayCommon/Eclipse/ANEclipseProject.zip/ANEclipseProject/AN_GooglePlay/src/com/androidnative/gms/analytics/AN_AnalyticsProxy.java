package com.androidnative.gms.analytics;

import com.androidnative.gms.utils.AnUtility;

import android.util.Log;

public class AN_AnalyticsProxy {

	// --------------------------------------
		// Analytics
		// --------------------------------------

		public static void StartAnalyticsTracking() {
			try {
				V4GoogleAnalytics.GetInstance().startAnalyticsTracking(AnUtility.GetLauncherActivity());
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void SetTrackerID(String trackingID) {
			try {
				V4GoogleAnalytics.GetInstance().SetTracker(trackingID);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void SendView(String appScreen) {

			try {
				V4GoogleAnalytics.GetInstance().SendView(appScreen);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		
		}

		public static void SendView() {
			try {
				V4GoogleAnalytics.GetInstance().SendView();
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void SendEvent(String category, String action, String label, String value) {
			try {
				V4GoogleAnalytics.GetInstance().sendEvent(category, action, label,
						value);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
			
		}

		public static void SendEvent(String category, String action, String label,String value, String key, String val) {
				try {
					V4GoogleAnalytics.GetInstance().sendEvent(category, action, label, 	value, key, val);
				} catch (Exception ex) {
					ex.printStackTrace();
					Log.d("AndroidNative", "Error: " + ex.getMessage());
				}
		}

		public static void SetKey(String key, String value) {
			try {
				V4GoogleAnalytics.GetInstance().setKey(key, value);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void ClearKey(String key) {
			try {
				V4GoogleAnalytics.GetInstance().clearKey(key);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void SendTiming(String category, String intervalInMilliseconds,String name, String label) {
			try {
				V4GoogleAnalytics.GetInstance().sendTiming(category,
						intervalInMilliseconds, name, label);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void CreateTransaction(String transactionId, String affiliation, String revenue, String tax, String shipping, String currencyCode) {
			try {
				V4GoogleAnalytics.GetInstance().CreateTransaction(transactionId,
						affiliation, revenue, tax, shipping, currencyCode);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void CreateItem(String transactionId, String name, String sku,String category, String price, String quantity, String currencyCode) {
			try {
				V4GoogleAnalytics.GetInstance().CreateItem(transactionId, name, sku,
						category, price, quantity, currencyCode);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		
		public static void SetLogLevel(String lvl) {
			try {
				V4GoogleAnalytics.GetInstance().SetLogLevel(Integer.parseInt(lvl));
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}

		public static void SetDryRun(String mode) {
			try {
				boolean m = false;
				if (mode.equals("true")) {
					m = true;
				} else {
					m = false;
				}
				
				V4GoogleAnalytics.GetInstance().setDryRun(m);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}
		
		public static void EnableAdvertisingIdCollection(String mode) {
			try {
				boolean m = false;
				if (mode.equals("true")) {
					m = true;
				} else {
					m = false;
				}
				
				V4GoogleAnalytics.GetInstance().enableAdvertisingIdCollection(m);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		}
}
