package com.androidnative.gms.listeners.savedgames;

import java.util.Iterator;

import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.snapshot.SnapshotMetadata;
import com.google.android.gms.games.snapshot.Snapshots.LoadSnapshotsResult;
import com.unity3d.player.UnityPlayer;



public class LoadSnapshotsResultListner implements  ResultCallback<LoadSnapshotsResult>{

	@Override
	public void onResult(LoadSnapshotsResult result) {
		StringBuilder info = new StringBuilder();
		info.append(result.getStatus().getStatusCode());
		info.append(GameClientManager.UNITY_SPLITTER);
		
		Iterator<SnapshotMetadata> iterator =  result.getSnapshots().iterator();
		while (iterator.hasNext()) {
			SnapshotMetadata meta = iterator.next();
			info.append(meta.getTitle());
			info.append(GameClientManager.UNITY_SPLITTER);
			info.append(meta.getLastModifiedTimestamp());
			info.append(GameClientManager.UNITY_SPLITTER);
			info.append(meta.getDescription());
			info.append(GameClientManager.UNITY_SPLITTER);
			info.append(meta.getCoverImageUrl());
			info.append(GameClientManager.UNITY_SPLITTER);
		}
		
		info.append(GameClientManager.UNITY_EOF);
		result.getSnapshots().release();
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnLoadSnapshotsResult", info.toString());

	}

}
