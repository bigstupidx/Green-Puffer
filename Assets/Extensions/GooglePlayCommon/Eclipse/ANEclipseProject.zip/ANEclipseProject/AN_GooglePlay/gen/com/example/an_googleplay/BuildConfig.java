/** Automatically generated file. DO NOT MODIFY */
package com.example.an_googleplay;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}